package ejercicio3;

public class ejercicio3 {

	public static void main(String[] args) {

		// Operaciones

		int a = 5;
		int b = 10;

		int Suma = a + b;
		int Resta = a - b;
		int Multiplicacion = a * b;
		int Division = a / b;

		// Incrementa y decrementa

		a++;
		b--;

		//Aumenta y multiplica

		a += 2;
		b *= 3;

		// Comprobar relacion
		boolean Igual = (a == b);
		boolean Diferente = (a != b);
		boolean MayorQue = (a > b);
		boolean MenorQue = (a < b);

		System.out.println("Suma: " + Suma);
		System.out.println("Resta: " + Resta);
		System.out.println("Producto: " + Multiplicacion);
		System.out.println("División: " + Division);
		System.out.println("Incremento de a: " + a);
		System.out.println("Decremento de b: " + b);
		System.out.println("Relación a == b: " + Igual);
		System.out.println("Relación a != b: " + Diferente);
		System.out.println("Relación a > b: " + MayorQue);
		System.out.println("Relación a < b: " + MenorQue);

		if (Igual && MayorQue) {
			System.out.println("a es igual a b y mayor que b.");
		} else if (Diferente || MenorQue) {
			System.out.println("a es diferente de b o menor que b.");
		} else {
			System.out.println("Distintas condiciones.");
		}

	}
}